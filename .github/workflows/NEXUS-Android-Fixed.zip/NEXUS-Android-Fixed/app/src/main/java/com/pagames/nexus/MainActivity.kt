package com.pagames.nexus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pagames.nexus.data.model.*
import com.pagames.nexus.data.repository.NexusRepository
import com.pagames.nexus.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { NexusTheme { NexusApp() } } }
}

private enum class Page { HOME, DECISION, RESULT, HISTORY, SETTINGS }
private data class SavedRun(val date: String, val profile: ProfileId, val count: Int)

@Composable private fun NexusApp() {
    val repo = remember { NexusRepository() }
    var page by remember { mutableStateOf(Page.HOME) }
    var index by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<ChoiceKey?>(null) }
    var answers by remember { mutableStateOf(mapOf<Int, ChoiceKey>()) }
    var profile by remember { mutableStateOf(ProfileId.ESTRATEGISTA) }
    var english by remember { mutableStateOf(false) }
    var sound by remember { mutableStateOf(true) }
    val history = remember { mutableStateListOf<SavedRun>() }
    val prefs = androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("nexus", 0)
    LaunchedEffect(Unit) {
        english = prefs.getBoolean("english", false); sound = prefs.getBoolean("sound", true)
        val saved = prefs.getString("history", "").orEmpty()
        saved.split(";").filter { it.contains("|") }.forEach { line -> val p=line.split("|"); runCatching { history.add(SavedRun(p[0], ProfileId.valueOf(p[1]), p.getOrElse(2){"5"}.toInt())) } }
    }
    fun reset() { index=0; selected=null; answers= emptyMap(); page=Page.DECISION }
    fun finish() { profile=repo.calculateProfile(answers); val date=SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date()); history.add(0, SavedRun(date, profile, answers.size)); while(history.size>20) history.removeAt(history.lastIndex); prefs.edit().putString("history", history.joinToString(";") { "${it.date}|${it.profile.name}|${it.count}" }).apply(); page=Page.RESULT }
    Scaffold(containerColor=NexusBlack, bottomBar={ if(page != Page.DECISION) { NavigationBar(containerColor=NexusSurface, contentColor=NexusText) { NavItem("Início","Home",page==Page.HOME){page=Page.HOME}; NavItem("Histórico","History",page==Page.HISTORY){page=Page.HISTORY}; NavItem("Definições","Settings",page==Page.SETTINGS){page=Page.SETTINGS} } } }) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) { when(page) {
            Page.HOME -> HomeScreen(english, onStart={reset()}, onHistory={page=Page.HISTORY}, onSettings={page=Page.SETTINGS})
            Page.DECISION -> DecisionScreen(repo.decisions[index], index, repo.decisions.size, selected, english, {selected=it}, { val c=selected; if(c!=null) { answers=answers+(repo.decisions[index].id to c); if(index+1<repo.decisions.size){index++;selected=null}else finish() } }, { page=Page.HOME })
            Page.RESULT -> ResultScreen(repo.profiles.getValue(profile), profile, english, { reset() }, { page=Page.HOME })
            Page.HISTORY -> HistoryScreen(history.toList(), english, {history.clear();prefs.edit().remove("history").apply()})
            Page.SETTINGS -> SettingsScreen(english, sound, {english=it;prefs.edit().putBoolean("english",it).apply()}, {sound=it;prefs.edit().putBoolean("sound",it).apply()})
        } }
    }
}

@Composable private fun RowScope.NavItem(pt:String,en:String,selected:Boolean,onClick:()->Unit) { NavigationBarItem(selected=selected,onClick=onClick,icon={ Text(if(pt=="Início") "⌂" else if(pt=="Histórico") "◷" else "⚙",fontSize=20.sp) },label={Text(if(en=="Home") "Home" else if(en=="History") "History" else if(selected && pt=="Definições") "Settings" else if(pt=="Definições") "Settings" else pt) },colors=NavigationBarItemDefaults.colors(selectedIconColor=NexusOrange,selectedTextColor=NexusOrange,indicatorColor=Color(0xFF352017),unselectedIconColor=NexusMuted,unselectedTextColor=NexusMuted)) }

@Composable private fun Brand() { Row(verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(NexusOrange),contentAlignment=Alignment.Center){Text("N",fontSize=23.sp,fontWeight=FontWeight.Black,color=Color.White)}; Spacer(Modifier.width(10.dp)); Column { Text("NEXUS",fontWeight=FontWeight.Black,fontSize=19.sp,letterSpacing=3.sp); Text("THE DECISION EXPERIENCE",fontSize=9.sp,color=NexusMuted,letterSpacing=1.5.sp) } } }
@Composable private fun PageColumn(content: @Composable ColumnScope.()->Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=22.dp, vertical=24.dp), content=content) }
@Composable private fun Eyebrow(text:String) { Text(text.uppercase(),color=NexusOrange,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp) }
@Composable private fun PrimaryButton(text:String,onClick:()->Unit,enabled:Boolean=true) { Button(onClick=onClick,enabled=enabled,modifier=Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=NexusOrange,contentColor=Color.White,disabledContainerColor=Color(0xFF503126),disabledContentColor=NexusMuted)) { Text(text,fontWeight=FontWeight.Bold,fontSize=15.sp) } }
@Composable private fun Panel(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit) { Column(modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(NexusSurface).border(1.dp,NexusBorder,RoundedCornerShape(18.dp)).padding(18.dp),content=content) }

@Composable private fun HomeScreen(english:Boolean,onStart:()->Unit,onHistory:()->Unit,onSettings:()->Unit) { PageColumn { Brand(); Spacer(Modifier.height(42.dp)); Eyebrow(if(english) "A CLEARER WAY FORWARD" else "UM CAMINHO MAIS CLARO"); Spacer(Modifier.height(12.dp)); Text(if(english) "Every choice
shapes what comes next." else "Cada escolha
constrói o próximo passo.",fontSize=36.sp,lineHeight=42.sp,fontWeight=FontWeight.Bold,color=NexusText); Spacer(Modifier.height(18.dp)); Text(if(english) "Explore your decision style through a short, interactive experience designed to help you reflect — not to label you." else "Explora a tua forma de decidir através de uma experiência interativa que te ajuda a refletir — sem te definir por um rótulo.",fontSize=16.sp,lineHeight=24.sp,color=NexusMuted); Spacer(Modifier.height(28.dp)); Panel { Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Eyebrow(if(english) "THE EXPERIENCE" else "A EXPERIÊNCIA"); Spacer(Modifier.height(8.dp)); Text(if(english) "5 scenarios · about 3 minutes" else "5 cenários · cerca de 3 minutos",fontWeight=FontWeight.SemiBold,fontSize=16.sp); Text(if(english) "No right or wrong answers." else "Não existem respostas certas ou erradas.",fontSize=13.sp,color=NexusMuted) }; Text("✦",fontSize=32.sp,color=NexusOrange) } }; Spacer(Modifier.height(18.dp)); PrimaryButton(if(english) "Begin experience  →" else "Começar experiência  →",onStart); Spacer(Modifier.height(12.dp)); OutlinedButton(onClick=onHistory,modifier=Modifier.fillMaxWidth().height(50.dp),shape=RoundedCornerShape(14.dp),border=ButtonDefaults.outlinedButtonBorder.copy(brush=androidx.compose.ui.graphics.SolidColor(NexusBorder))) { Text(if(english) "View history" else "Ver histórico",color=NexusText) }; Spacer(Modifier.height(28.dp)); Text(if(english) "A PA GAMES independent experience" else "Uma experiência independente PA GAMES",color=NexusMuted,fontSize=11.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth()) } }

@Composable private fun DecisionScreen(decision:Decision,index:Int,total:Int,selected:ChoiceKey?,english:Boolean,onSelect:(ChoiceKey)->Unit,onContinue:()->Unit,onExit:()->Unit) { PageColumn { Row(verticalAlignment=Alignment.CenterVertically) { Text("NEXUS",fontSize=14.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp,modifier=Modifier.weight(1f)); Text(if(english) "STEP ${index+1} OF $total" else "PASSO ${index+1} DE $total",fontSize=11.sp,color=NexusMuted); TextButton(onClick=onExit) { Text(if(english) "Exit" else "Sair",color=NexusMuted) } }; Spacer(Modifier.height(14.dp)); LinearProgressIndicator(progress=(index+1).toFloat()/total,modifier=Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(4.dp)),color=NexusOrange,trackColor=NexusBorder); Spacer(Modifier.height(36.dp)); Eyebrow(if(english) decision.categoryEn else decision.categoryPt); Spacer(Modifier.height(12.dp)); Text(if(english) decision.questionEn else decision.questionPt,fontSize=27.sp,lineHeight=34.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(26.dp)); decision.choices.forEachIndexed { i, choice -> val active=selected==choice.key; Column(Modifier.fillMaxWidth().padding(bottom=12.dp).clip(RoundedCornerShape(16.dp)).background(if(active) Color(0xFF29170F) else NexusSurface).border(1.dp,if(active) NexusOrange else NexusBorder,RoundedCornerShape(16.dp)).clickable { onSelect(choice.key) }.padding(16.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(if(active) NexusOrange else Color(0xFF252525)),contentAlignment=Alignment.Center){Text(choice.key.name,color=Color.White,fontWeight=FontWeight.Bold)}; Spacer(Modifier.width(12.dp)); Text(if(english) choice.titleEn else choice.titlePt,fontWeight=FontWeight.SemiBold,fontSize=15.sp,modifier=Modifier.weight(1f)); if(active) Text("✓",color=NexusOrange,fontSize=20.sp) }; Spacer(Modifier.height(9.dp)); Text(if(english) choice.detailEn else choice.detailPt,fontSize=13.sp,color=NexusMuted,lineHeight=19.sp,modifier=Modifier.padding(start=46.dp)) } }; Spacer(Modifier.height(12.dp)); PrimaryButton(if(index==total-1) {if(english) "See my reflection  →" else "Ver o meu resultado  →"} else {if(english) "Continue  →" else "Continuar  →"},onContinue,selected!=null); Spacer(Modifier.height(12.dp)); Text(if(english) "Choose what feels closest to you right now." else "Escolhe a opção que mais se aproxima de ti neste momento.",fontSize=12.sp,color=NexusMuted,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth()) } }

@Composable private fun ResultScreen(details:ProfileDetails,profile:ProfileId,english:Boolean,onRestart:()->Unit,onHome:()->Unit) { PageColumn { Brand(); Spacer(Modifier.height(34.dp)); Eyebrow(if(english) "YOUR REFLECTION" else "A TUA REFLEXÃO"); Spacer(Modifier.height(12.dp)); Text(if(english) "Your decision style" else "A tua forma de decidir",fontSize=30.sp,fontWeight=FontWeight.Bold,lineHeight=36.sp); Spacer(Modifier.height(22.dp)); Panel { Text("✦",fontSize=36.sp,color=NexusOrange); Spacer(Modifier.height(12.dp)); Text(if(english) details.titleEn else details.titlePt,fontSize=26.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(12.dp)); Text(if(english) details.descriptionEn else details.descriptionPt,fontSize=15.sp,lineHeight=23.sp,color=NexusMuted); Spacer(Modifier.height(20.dp)); Eyebrow(if(english) "A NEXT STEP" else "UM PRÓXIMO PASSO"); Spacer(Modifier.height(8.dp)); Text(if(english) details.adviceEn else details.advicePt,fontSize=15.sp,lineHeight=22.sp) }; Spacer(Modifier.height(18.dp)); Text(if(english) "This is a reflection based on your selections, not a psychological assessment or a fixed label. Different contexts can lead to different choices." else "Esta reflexão baseia-se nas tuas escolhas; não é uma avaliação psicológica nem um rótulo fixo. Contextos diferentes podem levar a decisões diferentes.",fontSize=12.sp,color=NexusMuted,lineHeight=18.sp); Spacer(Modifier.height(24.dp)); PrimaryButton(if(english) "Try again" else "Experimentar novamente",onRestart); Spacer(Modifier.height(10.dp)); OutlinedButton(onClick=onHome,modifier=Modifier.fillMaxWidth().height(50.dp),shape=RoundedCornerShape(14.dp)) { Text(if(english) "Back to home" else "Voltar ao início",color=NexusText) } } }

@Composable private fun HistoryScreen(history:List<SavedRun>,english:Boolean,onClear:()->Unit) { PageColumn { Brand(); Spacer(Modifier.height(32.dp)); Text(if(english) "Your history" else "O teu histórico",fontSize=30.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(if(english) "Your recent reflections are stored on this device." else "As tuas reflexões recentes ficam guardadas neste dispositivo.",color=NexusMuted,fontSize=14.sp,lineHeight=21.sp); Spacer(Modifier.height(22.dp)); if(history.isEmpty()) Panel { Text(if(english) "No experiences yet" else "Ainda sem experiências",fontWeight=FontWeight.Bold,fontSize=17.sp); Spacer(Modifier.height(6.dp)); Text(if(english) "Complete an experience and your result will appear here." else "Conclui uma experiência para veres o resultado aqui.",color=NexusMuted,fontSize=13.sp) } else { history.forEach { item -> Panel(Modifier.padding(bottom=12.dp)) { Text(item.date,fontSize=12.sp,color=NexusMuted); Spacer(Modifier.height(6.dp)); Text(if(english) item.profile.name.lowercase().replaceFirstChar{it.uppercase()} else when(item.profile){ProfileId.ESTRATEGISTA->"O Estrategista";ProfileId.EXPLORADOR->"O Explorador";ProfileId.ANALITICO->"O Analítico";ProfileId.COLABORADOR->"O Colaborador"},fontWeight=FontWeight.Bold,fontSize=17.sp); Text("${item.count} ${if(english) "answers" else "respostas"}",fontSize=13.sp,color=NexusMuted) } }; TextButton(onClick=onClear,modifier=Modifier.align(Alignment.End)) { Text(if(english) "Clear history" else "Apagar histórico",color=NexusOrange) } } } }

@Composable private fun SettingsScreen(english:Boolean,sound:Boolean,onLanguage:(Boolean)->Unit,onSound:(Boolean)->Unit) { PageColumn { Brand(); Spacer(Modifier.height(32.dp)); Text(if(english) "Settings" else "Definições",fontSize=30.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(22.dp)); Panel { Text(if(english) "Language" else "Idioma",fontSize=17.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text(if(english) "Choose the app language." else "Escolhe o idioma da aplicação.",fontSize=13.sp,color=NexusMuted); Spacer(Modifier.height(12.dp)); Row(verticalAlignment=Alignment.CenterVertically) { Text("Português",modifier=Modifier.weight(1f)); RadioButton(selected=!english,onClick={onLanguage(false)},colors=RadioButtonDefaults.colors(selectedColor=NexusOrange)) }; Row(verticalAlignment=Alignment.CenterVertically) { Text("English",modifier=Modifier.weight(1f)); RadioButton(selected=english,onClick={onLanguage(true)},colors=RadioButtonDefaults.colors(selectedColor=NexusOrange)) } }; Spacer(Modifier.height(14.dp)); Panel { Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(if(english) "Sound" else "Som",fontSize=17.sp,fontWeight=FontWeight.Bold); Text(if(english) "Sound preference for future features." else "Preferência para futuras funcionalidades.",fontSize=13.sp,color=NexusMuted,lineHeight=18.sp) }; Switch(checked=sound,onCheckedChange=onSound,colors=SwitchDefaults.colors(checkedThumbColor=Color.White,checkedTrackColor=NexusOrange)) } }; Spacer(Modifier.height(20.dp)); Text("NEXUS · THE DECISION EXPERIENCE
PA GAMES · v1.1.0",fontSize=11.sp,color=NexusMuted,lineHeight=18.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth()) } }
