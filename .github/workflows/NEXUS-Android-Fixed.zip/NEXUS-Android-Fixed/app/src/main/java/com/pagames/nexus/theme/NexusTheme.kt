package com.pagames.nexus.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NexusBlack = Color(0xFF070707)
val NexusSurface = Color(0xFF141414)
val NexusOrange = Color(0xFFFF5A1F)
val NexusText = Color(0xFFF5F5F5)
val NexusMuted = Color(0xFFAAAAAA)
val NexusBorder = Color(0xFF303030)
private val Scheme = darkColorScheme(primary=NexusOrange, onPrimary=Color.White, background=NexusBlack, onBackground=NexusText, surface=NexusSurface, onSurface=NexusText, secondary=Color(0xFFFFA276))
@Composable fun NexusTheme(content: @Composable () -> Unit) { MaterialTheme(colorScheme=Scheme, content=content) }
