package com.pagames.nexus.data.model

enum class ProfileId { ESTRATEGISTA, EXPLORADOR, ANALITICO, COLABORADOR }
enum class ChoiceKey { A, B, C }
data class Choice(val key: ChoiceKey, val titlePt: String, val titleEn: String, val detailPt: String, val detailEn: String, val profile: ProfileId)
data class Decision(val id: Int, val categoryPt: String, val categoryEn: String, val questionPt: String, val questionEn: String, val choices: List<Choice>)
data class ProfileDetails(val titlePt: String, val titleEn: String, val descriptionPt: String, val descriptionEn: String, val advicePt: String, val adviceEn: String)
data class DecisionRecord(val date: String, val profile: ProfileId, val answers: Int)
