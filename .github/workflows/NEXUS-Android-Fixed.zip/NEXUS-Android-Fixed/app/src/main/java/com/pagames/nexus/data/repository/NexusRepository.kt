package com.pagames.nexus.data.repository

import com.pagames.nexus.data.model.*

class NexusRepository {
    val decisions = listOf(
        Decision(1, "PRIORIDADES", "PRIORITIES", "Tens dois objetivos importantes e pouco tempo. O que fazes primeiro?", "You have two important goals and little time. What do you do first?", listOf(
            Choice(ChoiceKey.A,"Defino o objetivo com maior impacto","Choose the highest-impact goal","Priorizo pelo resultado esperado.","Prioritize by expected outcome.",ProfileId.ESTRATEGISTA),
            Choice(ChoiceKey.B,"Experimento um pouco de cada","Try a little of each","Aprendo enquanto exploro opções.","Learn while exploring options.",ProfileId.EXPLORADOR),
            Choice(ChoiceKey.C,"Peço dados e comparo","Gather data and compare","Decido com base em evidências.","Decide based on evidence.",ProfileId.ANALITICO))),
        Decision(2, "INCERTEZA", "UNCERTAINTY", "Uma oportunidade nova envolve algum risco. Como respondes?", "A new opportunity carries some risk. How do you respond?", listOf(
            Choice(ChoiceKey.A,"Defino limites e avanço","Set boundaries and proceed","Transformo risco em etapas geríveis.","Turn risk into manageable steps.",ProfileId.ESTRATEGISTA),
            Choice(ChoiceKey.B,"Faço um teste pequeno","Run a small experiment","Prefiro aprender pela experiência.","Prefer learning by experience.",ProfileId.EXPLORADOR),
            Choice(ChoiceKey.C,"Investigo antes de agir","Research before acting","Procuro reduzir a incerteza.","Try to reduce uncertainty.",ProfileId.ANALITICO))),
        Decision(3, "PESSOAS", "PEOPLE", "Uma decisão afeta várias pessoas. O que consideras?", "A decision affects several people. What do you consider?", listOf(
            Choice(ChoiceKey.A,"O objetivo e o plano","The goal and the plan","Mantenho o foco no resultado.","Keep focus on the outcome.",ProfileId.ESTRATEGISTA),
            Choice(ChoiceKey.B,"As perspetivas diferentes","Different perspectives","Procuro possibilidades que ainda não vi.","Look for possibilities I have not seen.",ProfileId.EXPLORADOR),
            Choice(ChoiceKey.C,"Ouço todos os envolvidos","Listen to everyone involved","Valorizo necessidades e colaboração.","Value needs and collaboration.",ProfileId.COLABORADOR))),
        Decision(4, "ESCOLHAS", "CHOICES", "Duas opções parecem igualmente válidas. Qual é o teu próximo passo?", "Two options seem equally valid. What is your next step?", listOf(
            Choice(ChoiceKey.A,"Escolho a que aproxima mais do objetivo","Choose the one closer to the goal","Uso o objetivo como bússola.","Use the goal as my compass.",ProfileId.ESTRATEGISTA),
            Choice(ChoiceKey.B,"Procuro uma terceira alternativa","Look for a third alternative","Questiono se existe outra via.","Ask whether another path exists.",ProfileId.EXPLORADOR),
            Choice(ChoiceKey.C,"Comparo vantagens e limites","Compare benefits and limits","Estruturo a decisão antes de escolher.","Structure the decision before choosing.",ProfileId.ANALITICO))),
        Decision(5, "APRENDIZAGEM", "LEARNING", "Depois de uma decisão difícil, o que te ajuda mais?", "After a difficult decision, what helps you most?", listOf(
            Choice(ChoiceKey.A,"Rever o resultado face ao objetivo","Review the outcome against the goal","Retiro lições orientadas para a ação.","Draw action-oriented lessons.",ProfileId.ESTRATEGISTA),
            Choice(ChoiceKey.B,"Explorar outras possibilidades","Explore other possibilities","Mantenho a curiosidade aberta.","Keep curiosity open.",ProfileId.EXPLORADOR),
            Choice(ChoiceKey.C,"Refletir com as pessoas envolvidas","Reflect with people involved","Aprendo com perspetivas partilhadas.","Learn from shared perspectives.",ProfileId.COLABORADOR)))
    )
    val profiles = mapOf(
        ProfileId.ESTRATEGISTA to ProfileDetails("O Estrategista","The Strategist","Transformas objetivos em passos concretos e procuras impacto. Este é um retrato orientativo das tuas respostas, não um diagnóstico.","You turn goals into concrete steps and seek impact. This is a reflection of your answers, not a diagnosis.","Define uma prioridade, um próximo passo e um prazo realista.","Define one priority, one next step, and a realistic deadline."),
        ProfileId.EXPLORADOR to ProfileDetails("O Explorador","The Explorer","Aprendes ao testar caminhos e manténs abertura para novas possibilidades. Este retrato é apenas orientativo.","You learn by testing paths and stay open to possibilities. This profile is only a guide.","Experimenta em pequena escala e regista o que descobrires.","Experiment on a small scale and record what you learn."),
        ProfileId.ANALITICO to ProfileDetails("O Analítico","The Analyst","Gostas de comparar opções e reduzir a incerteza antes de agir. Este retrato é apenas orientativo.","You like comparing options and reducing uncertainty before acting. This profile is only a guide.","Escolhe os dois critérios mais importantes e evita analisar sem fim.","Choose the two most important criteria and avoid endless analysis."),
        ProfileId.COLABORADOR to ProfileDetails("O Colaborador","The Collaborator","Tens em conta as pessoas envolvidas e procuras construir entendimento. Este retrato é apenas orientativo.","You consider the people involved and seek shared understanding. This profile is only a guide.","Clarifica necessidades, limites e o próximo passo acordado.","Clarify needs, boundaries, and the agreed next step."))
    fun calculateProfile(answers: Map<Int, ChoiceKey>): ProfileId {
        val scores = mutableMapOf<ProfileId, Int>().withDefault { 0 }
        decisions.forEach { d -> d.choices.firstOrNull { it.key == answers[d.id] }?.let { scores[it.profile] = scores.getValue(it.profile) + 1 } }
        return ProfileId.values().maxByOrNull { scores.getValue(it) } ?: ProfileId.ESTRATEGISTA
    }
}
