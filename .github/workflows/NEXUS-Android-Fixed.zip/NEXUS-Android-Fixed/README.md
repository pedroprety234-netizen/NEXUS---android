# NEXUS — THE DECISION EXPERIENCE

Projeto Android nativo reconstruído em Kotlin + Jetpack Compose, autoria PA GAMES.

## O que foi completado
- Interface de início, decisões, resultado, histórico e definições.
- Cinco cenários interativos e quatro perfis de reflexão.
- Seleção de respostas, barra de progresso, reinício e histórico local.
- Preferência de idioma Português/Inglês guardada no dispositivo.
- Manifesto simplificado e configuração Gradle sem dependências Room/KSP em falta.

## Gerar o APK
1. Extrai este ZIP num computador com Android Studio instalado.
2. Abre a pasta `NEXUS-Android-Fixed` no Android Studio.
3. Aguarda o Gradle Sync e instala os componentes de Android SDK sugeridos, se necessário.
4. Usa **Build > Build APK(s)**.
5. O APK de teste deverá aparecer em `app/build/outputs/apk/debug/app-debug.apk`.

Este ambiente de edição não tem Android SDK instalado, por isso o ZIP foi preparado como projeto-fonte; o APK ainda precisa de ser compilado no Android Studio. Para distribuir, cria uma assinatura própria em **Build > Generate Signed Bundle / APK**. Não uses credenciais de assinatura partilhadas.
